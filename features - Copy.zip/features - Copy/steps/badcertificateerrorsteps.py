from behave import *
import asyncio
import twtxt.models
import twtxt.twhttp
import twtxt.config
import aiohttp
from twtxt.cache import Cache


@given("a source <username> at <url> with a bad certificate")
def step_impl(context):
    context.ctx=twtxt.config.Config.discover()
    context.name="adiabatic"
    context.url="https://expired.badssl.com/"
    context.source=twtxt.models.Source(context.name,context.url)
@when("the goes to retreive tweets from the source")
def step_impl(context):
    with aiohttp.ClientSession() as client:
        loop = asyncio.get_event_loop()

        def start_loop(client, sources, limit, cache=None):
            return loop.run_until_complete(twtxt.twhttp.process_sources_for_file(client, sources, limit, cache))
        try:
            with Cache.discover() as cache:
                start_loop(client, [context.source], 7, cache)
        except Exception as caughtexception:
            context.error=caughtexception
@then("an error message stating there is a bad certificate should be displayed")
def step_impl(context):
    assert(context.error=="there has been a bad certificate")




@given("a source <username> at <url> with a valid certificate")
def step_impl(context):
    context.name="beyond"
    context.url="https://enotty.dk/beyond.txt"
    context.source=twtxt.models.Source(context.name,context.url)
@when("the program goes to retrieve tweets from that source")
def step_impl(context):
    with aiohttp.ClientSession() as client:

        loop = asyncio.get_event_loop()

        def start_loop(client, sources, limit, cache=None):
            return loop.run_until_complete(twtxt.twhttp.process_sources_for_file(client, sources, limit, cache))
        with Cache.discover() as cache:
            context.tweets=start_loop(client, [context.source], 7, cache)
@then("a number of tweets greater than 0 should be retreived")
def step_impl(context):
    assert(len(context.tweets)>0)